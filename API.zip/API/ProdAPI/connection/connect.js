var sql = require("mssql");
var connect = function()
{ 
    var conn = new sql.ConnectionPool({
        user: 'sa',
        password: 'w3bus3r@1957',
        server: 'ALGEM',
        database: 'ProductDB',
        port: 1433,
        connectionTimeout: 3000,
        requestTimeout: 3000,
        pool: {
            max: 100,
            min: 0, // 1 = don't close all the connections.
            idleTimeoutMillis: 1000,
            evictionRunIntervalMillis: 1500000
        },
        _options: {
            enableArithAbort: true
        },
        get options() {
            return this._options;
        },
        set options(value) {
            this._options = value;
        },
    });
    return conn;
};
module.exports = connect;

/*
Important note to check in your connection:
Built-in Service
	Local System
	Local Service
	Network Service <- This is my SQL configuration installation
*/
